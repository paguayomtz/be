<div class="divider indigo darken-3" style="width:95%; margin:0 auto;"></div>
<li>
    <a href="../usuarios/index.php" class="grey-text text-lighten-3"> <i class="material-icons grey-text text-lighten-3">group</i> USUARIOS </a>
</li>