<?php include '../extend/header.php'; ?>

<div class="row">
    <div class="center">
        <img src="../img/b_logo.png" alt="logo">
    </div>
</div>

<!--<div class="row">
    <div class="col s12">
        <div class="card">
            <div class="card content">
                <span class="card-title">Titulo</span>
                <p>Contenido</p>
            </div>
        </div>
    </div>
</div>-->

<?php include '../extend/scripts.php'; ?>

</body>
</html>





